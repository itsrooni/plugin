
function PopUp(url,width,height) {

Win=window.open(url,"Win",'width=' + width + ',height=' + height + ',toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0');

Win.focus();

 }